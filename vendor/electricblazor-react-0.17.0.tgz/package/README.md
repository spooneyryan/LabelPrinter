# @electricblazor/react

A React + TypeScript component suite: form inputs, overlays and dialogs, a date/time picker, a colour
picker, a multi-step wizard with conditional logic, a guided product tour, and visual editors for the
last two.

**Version:** 0.17.0 · MIT · React 18 or 19

The shared theme includes six additional light design skins: `walnut-paper`, `nordic-daylight`,
`color-study`, `copenhagen-grid`, `nordic-index`, and `timber-structure`. Self-hosted Latin fonts
and their OFL licenses are in the distributed `fonts/` directory; retain it beside `theme.css`
when copying the stylesheet as a static asset. Heading typography, decorative pill geometry,
and filled primary actions are distinct skin roles, with compatible existing-skin defaults.

Ported from [ElectricBlazor](https://dev.azure.com/MorrisonHotel/ElectricBlazor), a Blazor suite of
the same components. The two share one theme stylesheet, so a Blazor app and a React app can sit in
the same product and look like one thing. You do not need to know or care about the Blazor half to
use this.

## Install

```bash
npm install @electricblazor/react
```

React and React DOM are peer dependencies — this package brings no runtime dependencies of its own.

## Styles

Two stylesheets, and you need both unless you are supplying your own tokens:

```ts
import "@electricblazor/react/theme.css";  // design tokens: colour, spacing, radius, z-layers
import "@electricblazor/react/styles.css"; // the component rules, all var(--eb-*) references
```

They are separate on purpose. `theme.css` is the token layer shared with the Blazor suite, so a
hybrid app already loading it must not load a second copy; and an app with its own token values wants
the components without it. Import `theme.css` first, or override the tokens after it.

Nine skins ship in the theme. Set one on the document and every component follows:

```ts
document.documentElement.setAttribute("data-eb-theme", "electric");
```

`auto` resolves to a light or dark skin from `prefers-color-scheme`. `EbThemeSwitcher` is a ready-made
picker for all nine.

## Use

```tsx
import { EbButton, EbDialog, OverlayStackProvider } from "@electricblazor/react";

function Example() {
    const [open, setOpen] = useState(false);

    return (
        <OverlayStackProvider>
            <EbButton variant="primary" onClick={() => setOpen(true)}>Open</EbButton>
            <EbDialog open={open} title="Hello" onClose={() => setOpen(false)}>
                Anything you like.
            </EbDialog>
        </OverlayStackProvider>
    );
}
```

`OverlayStackProvider` wraps anything that stacks — dialogs, popovers, tours. It hands out z-indices
so a dialog opened from a popover lands above it. One near the root of the app is enough.

For a quick question, there is no need to put a dialog in your markup at all. Mount one
`EbDialogHost`, then await an answer from anywhere:

```tsx
const dialogs = useDialogs();

async function remove() {
    if (await dialogs.confirm("Delete 3 files?", { title: "Delete", confirmLabel: "Delete", confirmVariant: "danger" })) {
        await deleteFiles();
    }
}
```

`alert`, `confirm`, and `prompt` resolve to `void`, `boolean`, and `string | null`; Escape answers
Cancel, and an aborted `signal` closes the dialog from code. A destructive confirmation opens with
focus on Cancel.

## Entry points

The suite is one package with subpaths, so the pieces cannot drift out of version with each other.
Import only what you use; the rest is never bundled.

| Import | What is in it |
| --- | --- |
| `@electricblazor/react` | Buttons, cards, accordions, dialogs, popovers, tooltips, overlays, form inputs (`EbTextBox`, `EbCheckbox`, `EbSwitch`, `EbRadioGroup`, `EbSelect`, and the searchable `EbComboBox`, with local filtering or a debounced, abortable `searchAsync`) and the `EbFormField` frame they share, numeric input, tabbed cards, draggable and resizable boxes, a drag-and-keyboard sortable list, busy spinners, toast notifications, awaitable alert/confirm/prompt dialogs (`useDialogs` + `EbDialogHost`), the theme switcher, colour and number helpers |
| `@electricblazor/react/audio` | `EbAudioPlayer` — a gapless two-element audio player with a ten-band equalizer, canvas visualizers, and M3U playlists |
| `@electricblazor/react/datetime` | `EbDateTimePicker`, `EbMonthGrid`, `EbTimePanel`, and the `DateOnly`/`TimeOnly` value types |
| `@electricblazor/react/color` | `EbColorPicker` and the colour model |
| `@electricblazor/react/coolbuttons` | `EbCoolButtonGroup` — a retro segmented toggle bar with single selection |
| `@electricblazor/react/dockdrawers` | `EbEdgeTab` — a drawer docked to a screen edge, with an optional hover-to-reveal tab |
| `@electricblazor/react/graph` | `EbGraph` — an auto-scaling SVG point and line graph, with optional tooltips and a drag-to-scrub readout |
| `@electricblazor/react/wizard` | `EbWizard` — multi-step forms with validation, conditional steps, and resumable sessions |
| `@electricblazor/react/wizardstudio` | `EbWizardStudio`, a visual editor that authors wizard definitions and generates TypeScript |
| `@electricblazor/react/textcleaner` | `EbTextCleanerPanel` — twenty-five checks that clean pasted text: encoding garble, invisible characters, smart punctuation, RTF/PDF/email/spreadsheet artifacts, and a sensitive-data review |
| `@electricblazor/react/texteditor` | `EbTextEditor` — a sanitizing rich-text editor — and `EbCodeEditor`, a plain-text code surface |
| `@electricblazor/react/tile` | `EbTileGrid` — a dashboard board of draggable, resizable tiles that can be combined into tabbed groups — or, with `display: "accordion"` on the group, into stacked sections that open and close (`allowMultipleOpen`, `expandedIds`) under a header of the group's own; per-tile `capabilities` pin what a tile refuses (`{ move: false }`, `{ resize: false }`), hiding the matching handles and keyboard shortcuts. Omit `rows`/`columns` and the board fits its content, one spare row included. `zoom` (or `defaultZoom`, with `onZoomChange`) draws the whole board smaller — 25% to 100% by default — so a dashboard bigger than the screen can be arranged whole; every gesture still lands on the cell it would at full size. A `ref` gets `zoomIn()`, `zoomOut()` and `zoomToFit()`, and `wheelZoom` lets Ctrl/⌘ + wheel or a trackpad pinch zoom around the pointer. Buttons and fields inside a tile header act as themselves rather than starting drags, arrow keys stay with focused tile content, and a tile's accessible name leads with its title. `EbTileSettingsForm` renders a per-tile settings panel from a JSON-Schema fragment — diff-on-save, `null` for a cleared value, and a `renderField` escape hatch for custom controls |
| `@electricblazor/react/tour` | `EbTour` — guided product tours anchored to live elements |
| `@electricblazor/react/tourstudio` | `EbTourStudio`, the visual tour editor with an element picker |
| `@electricblazor/react/cssdesigner` | `EbCssEditor` — a CSS property panel that writes out only the properties you edit, each control named by its visible label — plus `EbCssRuleDesigner`, which edits a stylesheet rule by rule through it, `EbElementPicker` for inspect-and-pick selectors, and the `EbCssColorField` swatch-and-text colour input |
| `@electricblazor/react/loadergame` | `EbLoaderGame` — a playable breakout game as a loading indicator |
| `@electricblazor/react/save` | The save-menu and store abstraction the studios persist through |
| `@electricblazor/react/showcase` | `DemoShell`, `DemoSection` and `DemoSnippet` — the scaffold the suite's own demo pages are built from — with the catalog shape, the jump links and the heading slug a guide section needs |
| `@electricblazor/react/styles.css` | Every component stylesheet |
| `@electricblazor/react/theme.css` | The design tokens and the nine skins |

## Security note

`EbWizard` and `EbTour` accept **definitions** — plain data describing steps, fields, and validation —
which are meant to be authored by you, or by your own users through the studio components, and stored
somewhere you control.

A wizard field can carry a validation `pattern`, which is compiled to a `RegExp`. The Blazor original
bounds that with a `Regex` match timeout; JavaScript has no equivalent, and no way to interrupt a
running regular expression. A hostile pattern can therefore hang the tab (ReDoS).

**Do not load wizard definitions from untrusted sources.** If you must, validate the patterns before
compiling them, or run the wizard in a worker you can terminate.

Beyond that, the components use no `eval`, no `innerHTML`, and no `dangerouslySetInnerHTML` — enforced
by a lint test rather than by convention. Content passes through React's normal escaping.

## Browser support

**Chrome/Edge 102+, Firefox 112+, Safari 16.4+.**

Two things set that floor, and they fail very differently:

- **Regular-expression lookbehind** (`(?<=…)`, `(?<!…)`), used throughout the text-cleaning checks
  and in URL and punctuation handling. This is the Safari 16.4 constraint, and it is a **hard** one:
  an engine that does not support lookbehind rejects the pattern while *parsing* the file, so the
  module fails to load rather than misbehaving at runtime. There is no feature test that helps.
- **The `inert` attribute**, used by the overlay, the date picker, and the edge-tab drawer to take
  hidden panels out of the tab order. This is the Chrome 102 / Firefox 112 constraint, and it is
  **soft**: an engine that ignores `inert` still gets `aria-hidden`, so the panel is hidden from
  assistive technology and merely remains reachable by Tab.

Below those, the package also uses `structuredClone` and `Array.prototype.at` (Safari 15.4),
`replaceChildren` (Safari 14), `ResizeObserver`, `CSS.escape`, and Unicode property escapes
(`\p{…}`) — all comfortably within the range above.

`Intl.DateTimeFormat.formatToParts` is worth naming separately: the date picker takes its formats,
first-day-of-week, and 12/24-hour clock from `Intl` rather than shipping its own locale data, so it
follows the user's locale with no configuration.

> Earlier releases of this README claimed Chrome 79 / Firefox 63 / Safari 14. That was never quite
> right and became clearly wrong once the text-cleaning checks landed. If you are pinned to an older
> Safari, `@electricblazor/react/texteditor` and `@electricblazor/react/textcleaner` are the entry
> points to avoid; most of the rest of the suite is far less demanding.

## Notes on behaviour

- **Controlled and uncontrolled** both work, the React way: pass `value` to control a component,
  `defaultValue` to let it own its state. Every such prop has a matching `onXChange`.
- **Form validation is yours, the input shows it.** Every input takes `errorText` (and `helpText`,
  `required`, `label`): the message appears under the control, is announced through its
  `aria-describedby`, and marks it `aria-invalid`. Hand it whatever your form library reports.
  `required` adds the marker and `aria-required`, never the browser's own `required` popups.
- **Text commits when you leave the field.** `EbTextBox` reports a value on blur or Enter, so a
  re-render never fights the caret; pass `immediate` to hear every keystroke.
- **Choice values compare with `Object.is`.** Options whose values are equal without being the same
  object need `isEqual` on `EbSelect`, `EbRadioGroup`, or `EbComboBox`.
- **Refs work on React 18 and 19 alike.** A component that takes a `ref` hands it its root element
  (`EbButton`'s is the `<button>`, so it can anchor an `EbPopover`) or a handle of methods, typed
  `EbTileGridHandle`, `EbCssEditorHandle`, or `EbElementPickerHandle`.
- **Class names are stable.** Each component wears both a hashed CSS-Modules class and a plain,
  documented one (`eb-button`, `eb-dialog-header`), so you can target it from your own stylesheet and
  it will not break when this package is rebuilt.
- **ESM only.** No CommonJS build.

## Licence

MIT. See [LICENSE](./LICENSE).

---

Porting decisions, the divergence register, and the phase write-ups live in
[PORTING.md](./PORTING.md) — that is a document about how this was built, not about how to use it.
